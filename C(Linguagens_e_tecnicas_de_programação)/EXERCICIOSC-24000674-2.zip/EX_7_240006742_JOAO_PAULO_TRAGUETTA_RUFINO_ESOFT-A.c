#include <stdio.h>



int main (){
    int num1,num2,num3;
    printf("Digite 3 numeros\n");
    scanf("%d %d %d", &num1,&num2,&num3);
    printf("A media aritmetica entre os numeros e igual a: %d", (num1+num2+num3)/3 );




    return 0;
}