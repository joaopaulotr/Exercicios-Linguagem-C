#include <stdio.h>


int main(){
    float raio;
    printf("Digite o raio de seu circulo e descubra sua area: \n");
    scanf("%f", &raio);

    printf("o a area do seu circulo eh: %f", raio*raio*3,14);




    return 0;
}