#include <stdio.h>



int main () {
    int c;
    printf("Digite o seu valor em celcius para ser convertido em fahrenhei0:t\n");
    scanf("%d", &c);

    printf("%dC em fahrenheit eh igual a: %d", c, (1.8*c) + 32);





    return 0;
}