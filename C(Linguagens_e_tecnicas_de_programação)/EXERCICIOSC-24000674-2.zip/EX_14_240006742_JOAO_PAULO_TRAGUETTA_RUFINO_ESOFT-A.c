#include <stdio.h>

int raio(int num1){
num1 = (num1*num1)*3.14
}


int main(){
    int num1;
    printf("Digite um raio:\n");
    scanf("%d", &num1);
    num1 = raio(num1);
    printf("%d",num1);


    return 0;
}