#include <stdio.h>


int main(){
    int num1, num2;
    printf("Digite dois numeros: \n");
    scanf("%d%d", &num1, &num2);

    printf("A soma entre seu dois numeros eh: %d\n", num1+num2);
    printf("A subtração entre seu dois numeros eh: %d\n", num1-num2);
    printf("A multiplicação entre seu dois numeros eh: %d\n", num1*num2);
    printf("A divisao entre seu dois numeros eh: %d\n", num1/num2);




    return 0;
}