#include <stdio.h>
#include <string.h>

    int main () {
        char zero1 [50] = "Suave";
        char zero2 [] = "Amigo..";

        strncat (zero1,zero2,3);





        printf ("%s",zero1);
    }