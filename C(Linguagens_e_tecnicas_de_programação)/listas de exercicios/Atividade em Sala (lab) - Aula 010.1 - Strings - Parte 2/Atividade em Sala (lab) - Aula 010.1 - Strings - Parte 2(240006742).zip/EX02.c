#include <stdio.h> 
#include <string.h>
    int main () {
        char alo [50] = "jota";
        char aloalo [50] = "pe";

            if (strcmp (alo,aloalo) == 0) {
                printf ("iguais.");
            } else printf ("diferentes.");

    return 0;
    }