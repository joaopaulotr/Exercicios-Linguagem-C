#include <stdio.h>
#include <string.h>


int main(){
char autor1[20] = "Cleriton Savio";
char autor2[20] = "Matheus Guapo";

    


    if(strcmp(autor1, autor2) < 0){
        printf("Autor 1 é maior segundo o alfabeto");
    } else {
        printf("Autor 2 é maior segundo o alfabeto");
    }



}