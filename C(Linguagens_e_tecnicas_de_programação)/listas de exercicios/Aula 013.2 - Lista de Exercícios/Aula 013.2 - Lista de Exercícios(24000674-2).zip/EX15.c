//Exercício 3: Ordenação de Números
//Implemente um programa que:
//Solicite ao usuário que insira 5 números inteiros.
//Armazene esses números em um vetor de int.
//Ordene o vetor em ordem crescente e exiba o vetor
//ordenado.

#include <stdio.h>
#include <string.h>

int main(){
    int vet[5];
    int vet2[5];

    for(i = 0; i<5; i++){
        printf("%d", vet[i]);   
    } 

    vet2[5] = 0;

    
    
    return 0;
}