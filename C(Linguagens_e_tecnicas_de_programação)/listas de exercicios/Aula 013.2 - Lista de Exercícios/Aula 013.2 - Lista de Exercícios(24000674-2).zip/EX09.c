#include <stdio.h>
#include <string.h>

int main(){
    int i = 0;
    int ala[10];
        int ala2[10];
            int soma;


    for(i = 0; i < 2; i++){
        printf("Digite um numero\n");
        scanf("%d", &ala[i]);
    }
        i =0 ;

    for(i = 0; i < 2; i++){
        printf("Digite um numero\n");
        scanf("%d", &ala2[i]);}
   i = 0;

 for(i = 0; i < 2; i++){
    soma += ala[i] + ala2[i];
 }

 printf("%d", soma);

    return 0;
    }